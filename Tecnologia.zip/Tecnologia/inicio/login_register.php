<?php
session_start();
require_once 'config.php';

// Mostrar errores (solo para desarrollo)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Si se accede directamente sin POST, redirigir
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

// REGISTRO
if (isset($_POST['register'])) {
    $nombre = $_POST['name'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);

    // Validación básica
    if (empty($nombre) || empty($apellido) || empty($email) || empty($password)) {
        $_SESSION['register_error'] = 'Completa todos los campos';
        $_SESSION['active_form'] = 'register';
        header("Location: index.php");
        exit();
    }

    // Verificar si el email ya existe
    $checkEmail = $conn->query("SELECT email FROM usuarios WHERE email = '$email'");
    if ($checkEmail->num_rows > 0) {
        $_SESSION['register_error'] = '¡Este email ya está registrado!';
        $_SESSION['active_form'] = 'register';
    } else {
        $conn->query("INSERT INTO usuarios (nombre, apellido, email, password)
                      VALUES ('$nombre', '$apellido', '$email', '$password')");
    }

    header("Location: index.php");
    exit();
}

// INICIO DE SESIÓN
if (isset($_POST['login'])) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['contrasena'] ?? '';

    $result = $conn->query("SELECT * FROM usuarios WHERE email = '$email'");
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['email'] = $user['email'];
            $_SESSION['nombre'] = $user['nombre'];
            $_SESSION['rol'] = $user['tipo']; // 'admin' o 'usuario
            
            header("Location: ../principal/post.php");
            exit();
        }
    }

    // Si falla la verificación
    $_SESSION['login_error'] = 'Email o contraseña incorrectas';
    $_SESSION['active_form'] = 'login';
    header("Location: ../inicio/index.php");
    exit();
}
?>