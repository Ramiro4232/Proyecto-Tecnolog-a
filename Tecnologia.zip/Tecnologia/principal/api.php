<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['email'])) {
    echo json_encode(['error' => 'No estás logueado']);
    exit;
}

$mysqli = new mysqli('localhost', 'root', '', 'tecnologia_db');
if ($mysqli->connect_errno) {
    echo json_encode(['error' => 'Error de conexión']);
    exit;
}

$user_email = $_SESSION['email'];

// Obtener info del usuario para permisos
$stmt = $mysqli->prepare("SELECT tipo FROM usuarios WHERE email = ?");
$stmt->bind_param('s', $user_email);
$stmt->execute();
$stmt->bind_result($user_tipo);
$stmt->fetch();
$stmt->close();

$action = $_POST['action'] ?? '';

if ($action === 'valoracion') {
    // Dar like (insertar)
    $post_id = intval($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }
    // Ver si ya existe like
    $stmt = $mysqli->prepare("SELECT id FROM valoraciones WHERE post_id = ? AND user_email = ?");
    $stmt->bind_param('is', $post_id, $user_email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Ya dio like, no duplicar
        $stmt->close();
        echo json_encode(['error' => 'Ya diste like']);
        exit;
    } 
    $stmt->close();

    $stmt = $mysqli->prepare("INSERT INTO valoraciones (post_id, user_email, fecha) VALUES (?, ?, NOW())");
    $stmt->bind_param('is', $post_id, $user_email);
    $stmt->execute();
    $stmt->close();

    // Contar total likes
    $stmt = $mysqli->prepare("SELECT COUNT(*) FROM valoraciones WHERE post_id = ?");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $stmt->bind_result($total_likes);
    $stmt->fetch();
    $stmt->close();

    echo json_encode(['success' => true, 'total_likes' => $total_likes]);
    exit;

} elseif ($action === 'quitar_valoracion') {
    // Quitar like (borrar)
    $post_id = intval($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }

    $stmt = $mysqli->prepare("DELETE FROM valoraciones WHERE post_id = ? AND user_email = ?");
    $stmt->bind_param('is', $post_id, $user_email);
    $stmt->execute();
    $stmt->close();

    // Contar total likes
    $stmt = $mysqli->prepare("SELECT COUNT(*) FROM valoraciones WHERE post_id = ?");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $stmt->bind_result($total_likes);
    $stmt->fetch();
    $stmt->close();

    echo json_encode(['success' => true, 'total_likes' => $total_likes]);
    exit;

} elseif ($action === 'comentarios_list') {
    $post_id = intval($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }

    $stmt = $mysqli->prepare("SELECT c.id, c.user_email, c.comentario, c.fecha, u.nombre, u.apellido, u.tipo 
                              FROM comentarios c 
                              JOIN usuarios u ON c.user_email = u.email 
                              WHERE c.post_id = ? 
                              ORDER BY c.fecha ASC");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $comentarios = [];
    while ($row = $result->fetch_assoc()) {
        $comentarios[] = [
            'id' => $row['id'],
            'user_email' => $row['user_email'],
            'comentario' => htmlspecialchars($row['comentario']),
            'fecha' => $row['fecha'],
            'nombre' => htmlspecialchars($row['nombre']),
            'apellido' => htmlspecialchars($row['apellido']),
            'isAdmin' => ($user_tipo === 'admin') || ($row['user_email'] === $user_email)
        ];
    }
    echo json_encode(['success' => true, 'comentarios' => $comentarios]);
    exit;

} elseif ($action === 'comentario_add') {
    $post_id = intval($_POST['post_id'] ?? 0);
    $comentario = trim($_POST['comentario'] ?? '');
    if ($post_id <= 0 || empty($comentario)) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }

    $stmt = $mysqli->prepare("INSERT INTO comentarios (post_id, user_email, comentario, fecha) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param('iss', $post_id, $user_email, $comentario);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true]);
    exit;

} elseif ($action === 'comentario_eliminar') {
    $comentario_id = intval($_POST['comentario_id'] ?? 0);
    if ($comentario_id <= 0) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }

    // Verificar permiso: admin o dueño del comentario
    $stmt = $mysqli->prepare("SELECT user_email FROM comentarios WHERE id = ?");
    $stmt->bind_param('i', $comentario_id);
    $stmt->execute();
    $stmt->bind_result($due_email);
    if (!$stmt->fetch()) {
        $stmt->close();
        echo json_encode(['error' => 'Comentario no encontrado']);
        exit;
    }
    $stmt->close();

    if ($user_tipo !== 'admin' && $due_email !== $user_email) {
        echo json_encode(['error' => 'No tienes permiso para eliminar este comentario']);
        exit;
    }

    $stmt = $mysqli->prepare("DELETE FROM comentarios WHERE id = ?");
    $stmt->bind_param('i', $comentario_id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true]);
    exit;

} elseif ($action === 'editar_post') {
    $post_id = intval($_POST['post_id'] ?? 0);
    $contenido = trim($_POST['contenido'] ?? '');

    if ($post_id <= 0 || empty($contenido)) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }

    // Verificar que el usuario es dueño o admin
    $stmt = $mysqli->prepare("SELECT user_email FROM posts WHERE id = ?");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $stmt->bind_result($post_owner);
    if (!$stmt->fetch()) {
        $stmt->close();
        echo json_encode(['error' => 'Post no encontrado']);
        exit;
    }
    $stmt->close();

    if ($user_tipo !== 'admin' && $post_owner !== $user_email) {
        echo json_encode(['error' => 'No tienes permiso para editar este post']);
        exit;
    }

    $nueva_imagen_nombre = null;

    if (!empty($_FILES['imagen']['name'])) {
        $imagen = $_FILES['imagen'];
        $ext = strtolower(pathinfo($imagen['name'], PATHINFO_EXTENSION));
        $permitidas = ['jpg', 'jpeg', 'png', 'gif'];

        if (!in_array($ext, $permitidas)) {
            echo json_encode(['error' => 'Tipo de imagen no permitido']);
            exit;
        }

        $nueva_imagen_nombre = uniqid('postimg_') . '.' . $ext;
        $destino = __DIR__ . '/uploads/' . $nueva_imagen_nombre;

        if (!move_uploaded_file($imagen['tmp_name'], $destino)) {
            echo json_encode(['error' => 'Error al subir la imagen']);
            exit;
        }
    }

    if ($nueva_imagen_nombre !== null) {
        // Actualizar contenido e imagen
        $stmt = $mysqli->prepare("UPDATE posts SET contenido = ?, imagen = ?, fecha = NOW() WHERE id = ?");
        $stmt->bind_param('ssi', $contenido, $nueva_imagen_nombre, $post_id);
    } else {
        // Solo contenido
        $stmt = $mysqli->prepare("UPDATE posts SET contenido = ?, fecha = NOW() WHERE id = ?");
        $stmt->bind_param('si', $contenido, $post_id);
    }
    $stmt->execute();
    $stmt->close();

    $nuevo_contenido_html = nl2br(htmlspecialchars($contenido));
    $nueva_imagen_html = '';

    if ($nueva_imagen_nombre !== null) {
        $nueva_imagen_html = '<br><img src="uploads/' . htmlspecialchars($nueva_imagen_nombre) . '" alt="Imagen del post" style="max-width:100%; margin-top: 8px;">';
    }

    echo json_encode([
        'success' => true,
        'nuevo_contenido_html' => $nuevo_contenido_html,
        'nueva_imagen_html' => $nueva_imagen_html
    ]);
    exit;

} elseif ($action === 'eliminar_post') {
    $post_id = intval($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        echo json_encode(['error' => 'Datos inválidos']);
        exit;
    }

    // Verificar permiso admin o dueño post
    $stmt = $mysqli->prepare("SELECT user_email FROM posts WHERE id = ?");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $stmt->bind_result($post_owner);
    if (!$stmt->fetch()) {
        $stmt->close();
        echo json_encode(['error' => 'Post no encontrado']);
        exit;
    }
    $stmt->close();

    if ($user_tipo !== 'admin' && $post_owner !== $user_email) {
        echo json_encode(['error' => 'No tienes permiso para eliminar este post']);
        exit;
    }

    // Eliminar post (y sus comentarios y valoraciones por FK o manual si no FK)
    $stmt = $mysqli->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['error' => 'Acción inválida']);
exit;
