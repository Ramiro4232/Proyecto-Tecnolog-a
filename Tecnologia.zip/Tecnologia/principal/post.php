<?php
session_start();

if (!isset($_SESSION['email'])) {
    die("No estás logueado.");
}

$user_email = $_SESSION['email'];

$mysqli = new mysqli('localhost', 'root', '', 'tecnologia_db');
if ($mysqli->connect_errno) {
    die("Error al conectar con la base de datos: " . $mysqli->connect_error);
}

// Obtener datos del usuario (incluyendo tipo)
$stmtUser = $mysqli->prepare("SELECT nombre, apellido, tipo FROM usuarios WHERE email = ?");
$stmtUser->bind_param('s', $user_email);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$user = $resultUser->fetch_assoc();
$stmtUser->close();

$isAdmin = ($user['tipo'] === 'admin');

$sql = "SELECT 
    p.id, p.user_email, p.contenido, p.imagen, p.fecha, u.nombre, u.apellido,
    COALESCE(COUNT(v.valoracion), 0) AS total_valoraciones,
    COALESCE((
        SELECT valoracion FROM valoraciones v2 
        WHERE v2.post_id = p.id AND v2.user_email = ?
    ), 0) AS user_valoracion
FROM posts p
JOIN usuarios u ON p.user_email = u.email
LEFT JOIN valoraciones v ON v.post_id = p.id
GROUP BY p.id
ORDER BY p.fecha DESC
LIMIT 25";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param('s', $user_email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Inicio</title>
    <link rel="stylesheet" href="post.css?v=1">
</head>
<body class="dark-mode">

    <div class="top-buttons">
        <button id="mode-toggle-btn" aria-label="Cambiar modo" title="Cambiar modo">🌙</button>
        <form action="logout.php" method="post" style="margin: 0;">
            <button type="submit" id="logout-btn">Cerrar Sesión</button>
        </form>
    </div>

    <div class="new-post-btn-container">
        <a href="index.php" class="new-post-btn">Crear nuevo post</a>
        <a href="../principal/mensajes/mensajes.php" class="message-btn" title="Ir a mensajes">mensajes 💬</a>
    </div>

    <div class="container">
        <h1>Comunidad de Posts</h1>

        <?php while ($post = $result->fetch_assoc()): ?>
            <div class="post-card" data-postid="<?= htmlspecialchars($post['id']) ?>">
                <div class="post-header">
                    <?= htmlspecialchars($post['nombre'] . ' ' . $post['apellido']) ?>
                </div>

                <div class="post-content">
                    <?= nl2br(htmlspecialchars($post['contenido'])) ?>
                    <?php if (!empty($post['imagen'])): ?>
                        <br>
                        <img src="uploads/<?= htmlspecialchars($post['imagen']) ?>" alt="Imagen del post" style="max-width:100%; margin-top: 8px;">
                    <?php endif; ?>
                </div>

                <div class="post-footer">
                    <button class="valoracion-btn <?= $post['user_valoracion'] > 0 ? 'liked' : '' ?>" 
                        data-valoracion="<?= $post['user_valoracion'] ?>" data-postid="<?= $post['id'] ?>">
                        👍 <?= $post['total_valoraciones'] ?>
                    </button>
                    <button class="comentarios-btn" data-postid="<?= $post['id'] ?>">💬 Comentarios</button>

                    <?php if ($post['user_email'] === $user_email || $isAdmin): ?>
                        <button class="editar-post-btn" data-postid="<?= $post['id'] ?>">✏️ Editar</button>
                        <button class="eliminar-post-btn" data-postid="<?= $post['id'] ?>">🗑️ Eliminar</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- MODAL para editar post -->
    <div id="modalEditarPostFondo" class="modal" style="display:none;"></div>
    <div id="modalEditarPost" class="modal-content" style="display:none;">
        <button id="cerrarEditarModalBtn" class="modal-close">×</button>
        <h2>Editar Post</h2>
        <form id="editarPostForm" enctype="multipart/form-data">
            <input type="hidden" id="editarPostId" name="post_id" />
            <textarea id="editarContenido" name="contenido" rows="5" placeholder="Contenido"></textarea>
            <br>
            <label for="editarImagen">Cambiar imagen (opcional):</label><br>
            <input type="file" id="editarImagen" name="imagen" accept="image/*" />
            <br><br>
            <button type="submit">Guardar Cambios</button>
        </form>
    </div>

    <!-- MODAL de Comentarios -->
    <div id="modalFondo" class="modal"></div>
    <div id="modalComentarios" class="modal-content">
        <button id="cerrarModalBtn" class="modal-close">×</button>
        <div class="modal-header">Comentarios</div>
        <div id="comentariosList" class="comments-list"></div>
        <div class="comment-form">
            <textarea id="comentarioInput" placeholder="Escribe tu comentario..."></textarea>
            <button id="enviarComentarioBtn">Enviar</button>
        </div>
    </div>
    <script src="script.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', () => {
    });
</script>
</body>
</html>

<?php
$stmt->close();
$mysqli->close();
?>
