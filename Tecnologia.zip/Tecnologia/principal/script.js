const modal = document.getElementById('modalComentarios');
const modalFondo = document.getElementById('modalFondo');
const comentariosList = document.getElementById('comentariosList');
const comentarioInput = document.getElementById('comentarioInput');
const enviarComentarioBtn = document.getElementById('enviarComentarioBtn');
const cerrarModalBtn = document.getElementById('cerrarModalBtn');

const modalEditarPost = document.getElementById('modalEditarPost');
const modalEditarPostFondo = document.getElementById('modalEditarPostFondo');
const cerrarEditarModalBtn = document.getElementById('cerrarEditarModalBtn');
const editarPostForm = document.getElementById('editarPostForm');
const editarContenido = document.getElementById('editarContenido');
const editarPostId = document.getElementById('editarPostId');
const editarImagen = document.getElementById('editarImagen');

let currentPostId = null;

// --- VALORACIÓN (LIKE/DISLIKE) ---
document.querySelectorAll('.valoracion-btn').forEach(button => {
    button.addEventListener('click', () => {
        const postId = button.dataset.postid;
        const valoracionActual = parseInt(button.dataset.valoracion);

        // Si ya dio like, hacer dislike (restar)
        // Si no, dar like (sumar)
        const accion = valoracionActual > 0 ? 'quitar_valoracion' : 'valoracion';

        fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=${accion}&post_id=${postId}`
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (accion === 'valoracion') {
                    button.classList.add('liked');
                    button.dataset.valoracion = 1;
                } else {
                    button.classList.remove('liked');
                    button.dataset.valoracion = 0;
                }
                button.textContent = '👍 ' + data.total_likes;
            } else {
                alert(data.error || 'Error al valorar');
            }
        });
    });
});

// --- MOSTRAR COMENTARIOS ---
document.querySelectorAll('.comentarios-btn').forEach(button => {
    button.addEventListener('click', () => {
        currentPostId = button.dataset.postid;
        comentarioInput.value = '';
        comentariosList.innerHTML = '<p>Cargando comentarios...</p>';
        modal.style.display = 'flex';
        modalFondo.style.display = 'block';

        fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=comentarios_list&post_id=${currentPostId}`
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.comentarios.length === 0) {
                    comentariosList.innerHTML = '<p>No hay comentarios aún.</p>';
                } else {
                    comentariosList.innerHTML = data.comentarios.map(c => 
                        `<div class="comment">
                            <strong>${c.nombre} ${c.apellido}</strong> <small>${c.fecha}</small><br>
                            ${c.comentario}
                            ${c.isAdmin ? `<button class="eliminar-comentario-btn" data-comentarioid="${c.id}">🗑️</button>` : ''}
                        </div>`
                    ).join('');
                    // Agregar listener a botones eliminar comentarios si existen
                    document.querySelectorAll('.eliminar-comentario-btn').forEach(btn => {
                        btn.addEventListener('click', () => {
                            const comentarioId = btn.dataset.comentarioid;
                            if (confirm('¿Eliminar este comentario?')) {
                                fetch('api.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                    body: `action=comentario_eliminar&comentario_id=${comentarioId}`
                                })
                                .then(res => res.json())
                                .then(data => {
                                    if (data.success) {
                                        // Recargar comentarios
                                        document.querySelector(`button.comentarios-btn[data-postid="${currentPostId}"]`).click();
                                    } else {
                                        alert(data.error || 'Error al eliminar comentario');
                                    }
                                });
                            }
                        });
                    });
                }
            } else {
                comentariosList.innerHTML = `<p>Error al cargar comentarios</p>`;
            }
        });
    });
});

// --- ENVIAR COMENTARIO ---
enviarComentarioBtn.addEventListener('click', () => {
    const texto = comentarioInput.value.trim();
    if (texto.length === 0) {
        alert('El comentario no puede estar vacío.');
        return;
    }

    fetch('api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=comentario_add&post_id=${currentPostId}&comentario=${encodeURIComponent(texto)}`
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            comentarioInput.value = '';
            // Recargar comentarios después de enviar
            document.querySelector(`button.comentarios-btn[data-postid="${currentPostId}"]`).click();
        } else {
            alert(data.error || 'Error al enviar comentario');
        }
    });
});

// --- CERRAR MODAL COMENTARIOS ---
cerrarModalBtn.addEventListener('click', () => {
    modal.style.display = 'none';
    modalFondo.style.display = 'none';
});
modalFondo.addEventListener('click', () => {
    modal.style.display = 'none';
    modalFondo.style.display = 'none';
});

// --- MODAL EDITAR POST ---
const editarPostButtons = document.querySelectorAll('.editar-post-btn');
const eliminarPostButtons = document.querySelectorAll('.eliminar-post-btn');

editarPostButtons.forEach(button => {
    button.addEventListener('click', () => {
        const postId = button.dataset.postid;
        // Obtener contenido e imagen actual del post para llenar el formulario
        // Asumimos contenido está visible en el DOM
        const postCard = document.querySelector(`.post-card[data-postid="${postId}"]`);
        const contenido = postCard.querySelector('.post-content').innerText.trim();
        
        editarPostId.value = postId;
        editarContenido.value = contenido;
        editarImagen.value = '';

        modalEditarPost.style.display = 'block';
        modalEditarPostFondo.style.display = 'block';
    });
});

cerrarEditarModalBtn.addEventListener('click', () => {
    modalEditarPost.style.display = 'none';
    modalEditarPostFondo.style.display = 'none';
});
modalEditarPostFondo.addEventListener('click', () => {
    modalEditarPost.style.display = 'none';
    modalEditarPostFondo.style.display = 'none';
});

// --- ENVIAR EDITAR POST ---
editarPostForm.addEventListener('submit', e => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('action', 'editar_post');
    formData.append('post_id', editarPostId.value);
    formData.append('contenido', editarContenido.value);
    if (editarImagen.files.length > 0) {
        formData.append('imagen', editarImagen.files[0]);
    }

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Post actualizado correctamente');
            modalEditarPost.style.display = 'none';
            modalEditarPostFondo.style.display = 'none';

            // Actualizar contenido en la página sin recargar (opcional)
            const postCard = document.querySelector(`.post-card[data-postid="${editarPostId.value}"]`);
            postCard.querySelector('.post-content').innerHTML = data.nuevo_contenido_html;

            if (data.nueva_imagen_html !== undefined) {
                // Actualizar imagen (si viene)
                let img = postCard.querySelector('img');
                if (data.nueva_imagen_html === '') {
                    if (img) img.remove();
                } else {
                    if (img) {
                        img.outerHTML = data.nueva_imagen_html;
                    } else {
                        postCard.querySelector('.post-content').insertAdjacentHTML('beforeend', data.nueva_imagen_html);
                    }
                }
            }
        } else {
            alert(data.error || 'Error al actualizar post');
        }
    });
});

// --- ELIMINAR POST ---
eliminarPostButtons.forEach(button => {
    button.addEventListener('click', () => {
        const postId = button.dataset.postid;
        if (confirm('¿Seguro que quieres eliminar este post?')) {
            fetch('api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=eliminar_post&post_id=${postId}`
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert('Post eliminado');
                    // Remover el post del DOM
                    const postCard = document.querySelector(`.post-card[data-postid="${postId}"]`);
                    if (postCard) postCard.remove();
                } else {
                    alert(data.error || 'Error al eliminar post');
                }
            });
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('mode-toggle-btn');
    const body = document.body;

    // Cargar modo guardado
    const mode = localStorage.getItem('mode');
    if (mode === 'light') {
        body.classList.add('light-mode');
        body.classList.remove('dark-mode');
        btn.textContent = '☀️';
    } else {
        body.classList.add('dark-mode');
        body.classList.remove('light-mode');
        btn.textContent = '🌙';
    }

    // Cambiar modo al hacer clic
    btn.addEventListener('click', () => {
        if (body.classList.contains('dark-mode')) {
            body.classList.remove('dark-mode');
            body.classList.add('light-mode');
            btn.textContent = '☀️';
            localStorage.setItem('mode', 'light');
        } else {
            body.classList.remove('light-mode');
            body.classList.add('dark-mode');
            btn.textContent = '🌙';
            localStorage.setItem('mode', 'dark');
        }
    });
});