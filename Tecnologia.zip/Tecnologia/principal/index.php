<?php
session_start();
require_once '../inicio/config.php';  // Asegúrate de que la conexión `$conn` se incluya desde aquí

if (!isset($_SESSION['email'])) {
    header('Location: ../inicio/index.php');
    exit();
}

$user_email = $_SESSION['email'];
$nombre = $_SESSION['nombre'] ?? 'Usuario';

// Crear nuevo post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contenido = trim($_POST['contenido'] ?? '');
    $imagen_nombre = null;

    if (!empty($_FILES['imagen']['name'])) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($_FILES['imagen']['type'], $allowed_types)) {
            $ext = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
            $imagen_nombre = uniqid() . '.' . $ext;
            $destino = __DIR__ . '/uploads/' . $imagen_nombre;
            if (!is_dir(__DIR__ . '/uploads')) {
                mkdir(__DIR__ . '/uploads', 0755, true);
            }
            move_uploaded_file($_FILES['imagen']['tmp_name'], $destino);
        } else {
            $error = "Tipo de imagen no permitido.";
        }
    }

    if (empty($contenido) && !$imagen_nombre) {
        $error = "Debes escribir un texto o subir una imagen.";
    }

    if (!isset($error)) {
        $stmt = $conn->prepare("INSERT INTO posts (user_email, contenido, imagen) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $user_email, $contenido, $imagen_nombre);
        $stmt->execute();
        $stmt->close();

        header("Location: index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Post</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Bienvenido, <?= htmlspecialchars($nombre) ?> 👋</h1>

    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="index.php" method="POST" enctype="multipart/form-data">
        <textarea name="contenido" placeholder="¿Qué estás pensando?" maxlength="500"></textarea>
        <br />
        <input type="file" name="imagen" accept="image/*" />
        <br />
        <button type="submit">Publicar</button>
    </form>

    <div style="margin-top: 30px;">
        <a href="post.php" style="color:#0077cc; font-weight:bold;">🌐 Ver comunidad</a>
    </div>
</body>
</html>
