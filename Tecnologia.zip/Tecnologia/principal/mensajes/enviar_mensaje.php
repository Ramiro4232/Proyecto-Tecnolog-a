<?php
session_start();
require_once '../../inicio/config.php';

if (!isset($_SESSION['email'])) {
    die("No estás logueado.");
}

$emisor = $_SESSION['email'];
$receptor = $_POST['para'] ?? null;
$contenido = trim($_POST['mensaje'] ?? '');

if ($receptor && $contenido !== '') {
    $stmt = $conn->prepare("INSERT INTO mensajes (emisor_email, receptor_email, mensaje, fecha) VALUES (?, ?, ?, NOW())");

    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conn->error);
    }

    $stmt->bind_param('sss', $emisor, $receptor, $contenido);
    $stmt->execute();
    $stmt->close();
}

header("Location: mensajes.php?usuario=" . urlencode($receptor));
exit();
?>
