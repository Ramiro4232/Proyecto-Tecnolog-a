<?php
session_start();
require_once '../../inicio/config.php';

if (!isset($_SESSION['email'])) {
    die("No estás logueado.");
}

$mi_email = $_SESSION['email'];
$mi_nombre = $_SESSION['nombre'] ?? 'Usuario';

$usuario_seleccionado = $_GET['usuario'] ?? null;
$receptor_nombre = "";

// Si hay un usuario seleccionado, obtener su nombre y apellido
if ($usuario_seleccionado) {
    $stmt = $conn->prepare("SELECT nombre, apellido FROM usuarios WHERE email = ?");
    $stmt->bind_param('s', $usuario_seleccionado);
    $stmt->execute();
    $stmt->bind_result($nombreReceptor, $apellidoReceptor);
    if ($stmt->fetch()) {
        $receptor_nombre = $nombreReceptor . ' ' . $apellidoReceptor;
    } else {
        $receptor_nombre = $usuario_seleccionado; // fallback
    }
    $stmt->close();
}

// Obtener lista de usuarios (para enviar mensajes)
$usuarios = $conn->query("SELECT email, nombre, apellido FROM usuarios WHERE email != '$mi_email'");

// Obtener mensajes entre los dos usuarios seleccionados
$mensajes = [];
if ($usuario_seleccionado) {
    $stmt = $conn->prepare("
        SELECT m.emisor_email, m.mensaje, m.fecha, u.nombre, u.apellido
        FROM mensajes m
        INNER JOIN usuarios u ON u.email = m.emisor_email
        WHERE (m.emisor_email = ? AND m.receptor_email = ?) 
           OR (m.emisor_email = ? AND m.receptor_email = ?) 
        ORDER BY m.fecha ASC
    ");

    if (!$stmt) {
        die("Error en prepare(): " . $conn->error);
    }

    $stmt->bind_param('ssss', $mi_email, $usuario_seleccionado, $usuario_seleccionado, $mi_email);
    $stmt->execute();
    $resultado = $stmt->get_result();
    while ($fila = $resultado->fetch_assoc()) {
        $mensajes[] = $fila;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mensajes Privados</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
        .chat-box { background-color: #fff; border: 1px solid #ccc; padding: 10px; margin-bottom: 20px; }
        .mensaje { margin-bottom: 15px; }
        .mensaje strong { color: #007BFF; }
        .usuarios a { display: block; margin-bottom: 5px; }
        textarea { width: 100%; padding: 8px; }
        button { margin-top: 10px; padding: 8px 12px; }
    </style>

    <link rel="stylesheet" href="mensajes.css">
</head>
<body>

<header class="header-top">
    <div class="logo">
        <div class="icon"></div>
        Sky Line
        <span class="corp">Corp</span>
    </div>

    <a href="../post.php" class="btn-volver">
        ← Volver a Principal
    </a>
</header>

    <h1>Mensajes Privados</h1>
    <h1>Bienvenido, <?= htmlspecialchars($mi_nombre) ?></h1>

    <h3><u>Enviar mensaje a:</u></h3>
    <div class="usuarios">
        <?php if ($usuarios->num_rows > 0): ?>
            <?php while ($u = $usuarios->fetch_assoc()): ?>
                <a href="?usuario=<?= urlencode($u['email']) ?>">
                    <?= htmlspecialchars($u['nombre'] . ' ' . $u['apellido']) ?>
                </a>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No hay otros usuarios disponibles.</p>
        <?php endif; ?>
    </div>

    <?php if ($usuario_seleccionado): ?>
        <h3>Conversación con <?= htmlspecialchars($receptor_nombre) ?></h3>
        <div class="chat-box">
            <?php if (empty($mensajes)): ?>
                <p>No hay mensajes aún.</p>
            <?php else: ?>
                <?php foreach ($mensajes as $m): ?>
                    <div class="mensaje">
                        <strong>
                            <?= $m['emisor_email'] === $mi_email ? 'Tú' : htmlspecialchars($m['nombre'] . ' ' . $m['apellido']) ?>:
                        </strong>
                        <?= htmlspecialchars($m['mensaje']) ?><br>
                        <small><?= $m['fecha'] ?></small>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Formulario para enviar mensaje -->
        <form method="post" action="enviar_mensaje.php">
            <input type="hidden" name="para" value="<?= htmlspecialchars($usuario_seleccionado) ?>">
            <textarea name="mensaje" rows="3" placeholder="Escribe tu mensaje..." required></textarea><br>
            <button type="submit">Enviar</button>
        </form>
    <?php else: ?>
        <p><i>Selecciona un usuario para iniciar una conversación.</i></p>
    <?php endif; ?>

</body>
</html>
